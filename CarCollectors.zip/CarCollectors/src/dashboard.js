import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAT8lAk-MzVwnSdSyu8dZhCuuNUDkhaq0o",
  authDomain: "car-collectors-49072.firebaseapp.com",
  projectId: "car-collectors-49072",
  storageBucket: "car-collectors-49072.firebasestorage.app",
  messagingSenderId: "94851011167",
  appId: "1:94851011167:web:3866a680a9d5046fe7c1ea",
  measurementId: "G-B3WRJXQQ0G"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Auth state observer
auth.onAuthStateChanged((user) => {
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  loadUserData(user.uid);
});

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', (e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    window.location.href = 'index.html';
  });
});

// Load user data
async function loadUserData(userId) {
  // Continuing from the loadUserData function:
  try {
    // Simulate data loading (replace with actual Firestore queries)
    document.getElementById('playerName').textContent = "Speed Demon";
    document.getElementById('garageValue').textContent = "2,500,000";
    document.getElementById('carsOwned').textContent = "12";
    document.getElementById('racesWon').textContent = "47";

    // Update level and XP
    document.getElementById('playerLevel').textContent = "35";
    document.getElementById('currentXP').textContent = "8,450";
    document.getElementById('requiredXP').textContent = "10,000";

    // Animate XP progress bar
    animateXPProgress(8450, 10000);

    // Load car stats
    loadCarStats();

    // Set up event listeners for race buttons
    setupEventListeners();
  } catch (error) {
    console.error("Error loading user data:", error);
  }
}

// Animate XP progress bar
function animateXPProgress(current, max) {
  const progressBar = document.getElementById('xpProgress');
  const percentage = (current / max) * 100;
  let width = 0;
  const interval = setInterval(() => {
    if (width >= percentage) {
      clearInterval(interval);
    } else {
      width++;
      progressBar.style.width = width + '%';
    }
  }, 10);
}

// Load car statistics
function loadCarStats() {
  // Simulate loading car stats (replace with actual data)
  const stats = {
    horsePower: 750,
    acceleration: "3.2s",
    grip: 9,
    downforce: "High",
    topSpeed: 215,
    rating: "S+"
  };

  // Update car stat elements
  Object.keys(stats).forEach(stat => {
    const element = document.getElementById(stat);
    if (element) {
      element.textContent = stats[stat];
    }
  });

  // Add hover effect to car display
  const carDisplay = document.querySelector('.car-display');
  carDisplay.addEventListener('mousemove', (e) => {
    const rect = carDisplay.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const rotateY = (x / rect.width - 0.5) * 20;
    carDisplay.style.transform = `rotateY(${rotateY}deg)`;
  });

  carDisplay.addEventListener('mouseleave', () => {
    carDisplay.style.transform = 'rotateY(0deg)';
  });
}

// Set up event listeners
function setupEventListeners() {
  // Add click handlers for race buttons
  const raceButtons = document.querySelectorAll('.event-item .btn');
  raceButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      const eventName = e.target.parentElement.querySelector('h3').textContent;
      enterRace(eventName);
    });
  });

  // Add hover animations for stat cards
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-5px)';
      card.style.boxShadow = '0 5px 15px rgba(255, 0, 0, 0.2)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0)';
      card.style.boxShadow = 'none';
    });
  });
}

// Handle race entry
function enterRace(eventName) {
  // Add race entry logic here
  console.log(`Entering race: ${eventName}`);

  // Example notification
  showNotification(`Registered for ${eventName}! Race begins in 2 minutes.`);
}

// Show notification
function showNotification(message) {
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.style.cssText = `
			position: fixed;
			top: 20px;
			right: 20px;
			background: rgba(255, 30, 30, 0.9);
			padding: 1rem;
			border-radius: 8px;
			box-shadow: 0 0 20px rgba(255, 0, 0, 0.3);
			z-index: 1000;
			animation: slideIn 0.3s ease-out;
			`;
  notification.textContent = message;

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-in';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Add animation keyframes
const style = document.createElement('style');
style.textContent = `
			@keyframes slideIn {
			from { transform: translateX(100%); opacity: 0; }
			to { transform: translateX(0); opacity: 1; }
			}
			@keyframes slideOut {
			from { transform: translateX(0); opacity: 1; }
			to { transform: translateX(100%); opacity: 0; }
			}
			`;
document.head.appendChild(style);

// Initialize the dashboard
loadUserData();