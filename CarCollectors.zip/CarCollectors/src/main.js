import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-analytics.js";

const firebaseConfig = {
  apiKey: "AIzaSyAT8lAk-MzVwnSdSyu8dZhCuuNUDkhaq0o",
  authDomain: "car-collectors-49072.firebaseapp.com",
  projectId: "car-collectors-49072",
  storageBucket: "car-collectors-49072.firebasestorage.app",
  messagingSenderId: "94851011167",
  appId: "1:94851011167:web:3866a680a9d5046fe7c1ea",
  measurementId: "G-B3WRJXQQ0G"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);

// DOM Elements
const authForm = document.getElementById('authForm');
const toggleMode = document.getElementById('toggleMode');
const toggleText = document.getElementById('toggleText');
const submitBtn = document.getElementById('submitBtn');
const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');

// State
let isSignUp = false;

// Helper Functions
function showError(element, message) {
  element.textContent = message;
  element.style.display = 'block';
  element.closest('.form-group').querySelector('input').classList.add('shake');
  setTimeout(() => {
    element.closest('.form-group').querySelector('input').classList.remove('shake');
  }, 500);
}

function clearErrors() {
  emailError.style.display = 'none';
  passwordError.style.display = 'none';
  emailError.textContent = '';
  passwordError.textContent = '';
}

function updateFormMode() {
  isSignUp = !isSignUp;
  submitBtn.textContent = isSignUp ? 'Sign Up' : 'Sign In';
  toggleText.textContent = isSignUp ? 'Already have an account?' : "Don't have an account?";
  toggleMode.textContent = isSignUp ? 'Sign In' : 'Sign Up';
  clearErrors();
}

// Auth Functions
async function handleAuth(email, password) {
  try {
    let userCredential;
    if (isSignUp) {
      userCredential = await createUserWithEmailAndPassword(auth, email, password);
    } else {
      userCredential = await signInWithEmailAndPassword(auth, email, password);
    }
    return userCredential;
  } catch (error) {
    throw error;
  }
}

// Event Listeners
toggleMode.addEventListener('click', updateFormMode);

authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    submitBtn.disabled = true;
    submitBtn.textContent = isSignUp ? 'Creating Account...' : 'Signing In...';

    await handleAuth(email, password);
    // Successful auth will trigger onAuthStateChanged
  } catch (error) {
    console.error("Auth error:", error);

    switch (error.code) {
      case 'auth/email-already-in-use':
        showError(emailError, 'Email already in use');
        break;
      case 'auth/invalid-email':
        showError(emailError, 'Invalid email address');
        break;
      case 'auth/weak-password':
        showError(passwordError, 'Password should be at least 6 characters');
        break;
      case 'auth/user-not-found':
        showError(emailError, 'User not found');
        break;
      case 'auth/wrong-password':
        showError(passwordError, 'Incorrect password');
        break;
      default:
        showError(emailError, error.message);
    }
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = isSignUp ? 'Sign Up' : 'Sign In';
  }
});

// Auth State Observer
onAuthStateChanged(auth, (user) => {
  if (user) {
    // User is signed in
    console.log("User signed in:", user.uid);
    window.location.href = 'dashboard.html';
  } else {
    // User is signed out
    console.log("User is signed out");
  }
});

// Check if we're on the dashboard page and not logged in
if (window.location.pathname.includes('dashboard.html')) {
  onAuthStateChanged(auth, (user) => {
    if (!user) {
      window.location.href = 'index.html';
    }
  });
}